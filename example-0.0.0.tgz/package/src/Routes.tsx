import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import SideBar from './components/SideBar';
import App from './App';
import UploadImage from './components/UploadImage';
import {
    CogBitmapLayerExample, CogMultibandExample,
    CogTerrainLayerExample, CogTerrainGlazeExample, CogTerrainKernelExample, CogAnimationExample
} from './examples';

interface RoutesProps {}

const Routing: React.FC<RoutesProps> = () => (
  <BrowserRouter
    future={{
      v7_startTransition: true,
      v7_relativeSplatPath: true,
    }}
  >
    <SideBar />
    <UploadImage />
    <Routes>
      <Route path={'/'} element={<App />} />
      <Route path={'/cog-bitmap-layer-example'} element={<CogBitmapLayerExample />} />
      <Route path={'/cog-terrain-layer-example'} element={<CogTerrainLayerExample />} />
      <Route path={'/cog-terrain-glaze-example'} element={<CogTerrainGlazeExample />} />
      <Route path={'/cog-multiband-example'} element={<CogMultibandExample />} />
      <Route path={'/cog-terrain-kernel-example'} element={<CogTerrainKernelExample />}/>
      <Route path={'/cog-animation-example'} element={<CogAnimationExample />} />
    </Routes>
  </BrowserRouter>
);

export default Routing;
